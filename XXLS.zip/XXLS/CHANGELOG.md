# Change Log

## [2.1.0] 2023-01-10

- Update dependencies and devDependencies
- Migrate from `node-sass` to `sass`
- Fix installation issue when running `npm i`

## [2.0.0] 2019-02-14

- Update to Bootstrap 4
- Update to Vue CLI 3
- Several UI fixes & improvements
- Cleanup and simplify code structure
- Add pwa support

## [1.0.0] 2017-06-18

### Stable Original Release
