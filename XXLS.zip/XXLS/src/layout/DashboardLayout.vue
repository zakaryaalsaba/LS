<template>
  <div class="wrapper">
    <side-bar>
      <mobile-menu slot="content"></mobile-menu>
      <!-- <sidebar-link to="/admin/overview"> -->
        <sidebar-link to="/admin/user">
        <i class="nc-icon nc-grid-45"></i>
        <p>Dashboard</p>
      </sidebar-link>
      <sidebar-link to="/admin/csRequest">
        <i class="nc-icon nc-alien-33"></i>
        <p>CS REQUEST</p>
      </sidebar-link>
      <sidebar-link to="/admin/Loan">
        <i class="nc-icon nc-paper-2"></i>
        <p>LOAN</p>
      </sidebar-link>
      <sidebar-link to="/admin/Surrender">
        <i class="nc-icon nc-app"></i>
        <p>SURRENDER</p>
      </sidebar-link>
      <sidebar-link to="/admin/Adjstment">
        <i class="nc-icon nc-notes"></i>
        <p>ADJSTMENT</p>
      </sidebar-link>
      <sidebar-link to="/admin/View">
        <i class="nc-icon nc-bullet-list-67"></i>
        <p>VIEW</p>
      </sidebar-link>
      <sidebar-link to="/admin/Pending">
        <i class="nc-icon nc-bulb-63"></i>
        <p>PENDING</p>
      </sidebar-link>
      <sidebar-link to="/admin/Print">
        <i class="nc-icon nc-camera-20"></i>
        <p>PRINT</p>
      </sidebar-link>
      <sidebar-link to="/admin/icons">
        <i class="nc-icon nc-atom"></i>
        <p>Icons</p>
      </sidebar-link>
      <!-- <sidebar-link to="/admin/user">
        <i class="nc-icon nc-circle-09"></i>
        <p>User Profile</p>
      </sidebar-link> -->
      <!-- <sidebar-link to="/admin/user">
        <i class="nc-icon nc-circle-09"></i>
        <p>User Profile</p>
      </sidebar-link>
      <sidebar-link to="/admin/table-list">
        <i class="nc-icon nc-notes"></i>
        <p>Table list</p>
      </sidebar-link>
      <sidebar-link to="/admin/typography">
        <i class="nc-icon nc-paper-2"></i>
        <p>Typography</p>
      </sidebar-link>
      <sidebar-link to="/admin/icons">
        <i class="nc-icon nc-atom"></i>
        <p>Icons</p>
      </sidebar-link>
      <sidebar-link to="/admin/maps">
        <i class="nc-icon nc-pin-3"></i>
        <p>Maps</p>
      </sidebar-link>
      <sidebar-link to="/admin/notifications">
        <i class="nc-icon nc-bell-55"></i>
        <p>Notifications</p>
      </sidebar-link> -->

      <!-- <template slot="bottom-links">
        <sidebar-link class="active"
                      to="/admin/upgrade">
          <i class="nc-icon nc-alien-33"></i>
          <p>Upgrade to PRO</p>
        </sidebar-link>
      </template> -->
      

    </side-bar>
    <div class="main-panel">
      <top-navbar></top-navbar>

      <dashboard-content @click="toggleSidebar">

      </dashboard-content>

      <content-footer></content-footer>
    </div>
  </div>
</template>
<style lang="scss"></style>
<script>
import TopNavbar from './TopNavbar.vue'
import ContentFooter from './ContentFooter.vue'
import DashboardContent from './Content.vue'
import MobileMenu from './MobileMenu.vue'
export default {
  components: {
    TopNavbar,
    ContentFooter,
    DashboardContent,
    MobileMenu
  },
  methods: {
    toggleSidebar() {
      if (this.$sidebar.showSidebar) {
        this.$sidebar.displaySidebar(false)
      }
    }
  }
}

</script>
