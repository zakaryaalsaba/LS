<template>
  <ul class="nav nav-mobile-menu">
    <!-- <base-dropdown>
      <template slot="title">
        <i class="fa fa-globe"></i>
        <b class="caret"></b>
        <span class="notification">5 Notifications</span>
      </template>
      <a class="dropdown-item" href="#">Notification 1</a>
      <a class="dropdown-item" href="#">Notification 2</a>
      <a class="dropdown-item" href="#">Notification 3</a>
      <a class="dropdown-item" href="#">Notification 4</a>
      <a class="dropdown-item" href="#">Another notification</a>
    </base-dropdown> -->
    <li class="nav-item">
      <a href="#" class="nav-link">
        <i class="nc-icon nc-zoom-split hidden-lg-up"></i>
        <span class="d-lg-none">Search</span>
      </a>
    </li>
    <base-dropdown title="Company">
      <a class="dropdown-item" href="#">Globe Life / FUA</a>
      <a class="dropdown-item" href="#">Liberity Nat'l / UIL</a>
      <a class="dropdown-item" href="#">Military Business</a>
      <a class="dropdown-item" href="#">United American (PINQ)</a>
      <a class="dropdown-item" href="#">United American - CFU</a>
      <!-- <div class="divider"></div>
      <a class="dropdown-item" href="#">Separated link</a> -->
    </base-dropdown>

    <li class="nav-item">
      <a class="nav-link" href="#pablo">
        <span class="no-icon">Log out</span>
      </a>
    </li>
  </ul>
</template>
<script>
export default {
  name: 'mobile-menu'
}
</script>
<style></style>
