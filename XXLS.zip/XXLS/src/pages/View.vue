<template>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8">
          View
        </div>
        <div class="col-md-4">
          View
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    components: {
    }
  }

</script>
<style>

</style>
