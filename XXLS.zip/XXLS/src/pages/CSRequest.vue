<template>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8">
          CSRequest
        </div>
        <div class="col-md-4">
          CSRequest
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    components: {
    }
  }

</script>
<style>

</style>
