<template>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8">
          Loan
        </div>
        <div class="col-md-4">
          Loan
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    components: {
    }
  }

</script>
<style>

</style>
